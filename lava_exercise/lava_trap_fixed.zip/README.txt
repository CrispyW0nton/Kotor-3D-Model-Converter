# Lava Trap – Fixed KotOR MDL Files
======================================

## What's in this zip

fixed_models/
  lava_trap.mdl / .mdx      – flat 3×3 m lava plane (classification=item)
  lava_floor.mdl / .mdx     – same geometry, model name = 'lava_floor'
  plc_lavapudl.mdl / .mdx   – organic puddle shape (95 verts) with lava1 texture

textures/
  lava1.tga / lava2.tga / lava3.tga   – 512×512 lava textures

renders/
  *_render.png               – software-rendered preview of each model
  _lava_composite.png        – side-by-side comparison of all three

## How to use in KotOR

1. Copy lava_trap.mdl + lava_trap.mdx + lava1.tga into your
   game's Override/ folder.

2. The texture filename MUST match the name inside the MDL exactly.
   These files are set to 'lava1' → texture file must be 'lava1.tga'.

3. To swap to lava2 or lava3:
   python tools/mdl_patch_texture.py lava_trap.mdl lava2
   (then copy lava2.tga to Override as well)

## What was wrong / what was fixed

| Model            | Original problem            | Fix applied                      |
|------------------|-----------------------------|----------------------------------|
| lava_trap.mdl    | Texture = 'LSL_logos'       | Changed to 'lava1'               |
|                  | Vertices at Z≈2.5, off-center | Rebuilt MDX: Z=0, centered 3m   |
| plc_glowpudl.mdl | Texture = 'PLC_BldPdlSm'    | Changed to 'lava1' → plc_lavapudl|
| plc_acd.mdl      | Particle splash+Lighten      | Not included; needs emitter strip|

## Key MDL binary layout (for future reference)

  File header   : bytes 0-11   (zero_key, mdl_size, mdx_size)
  Geometry hdr  : bytes 12-91  (fp1/fp2 magic, model name @+8, root_node_off @+40)
  Model hdr     : bytes 92-179 (classification @+0, bb_min @+24, radius @+48)
  Node header   : 80 bytes     (flags @+0, children_off @+44, children_cnt @+48)
  Mesh extension: after node header (trimesh flag = 0x20)
    +88  primary texture name (32 bytes, null-padded)
    +120 lightmap  name       (32 bytes)
    +256 MDX data bitmap      (4 bytes)
    +260 MDX channel offsets  (11×4 bytes: pos, normal, vc, uv, lm, uv2, uv3...)
    +304 vert_count (uint16)
    +306 tex_count  (uint16)

  MDX stride (typical K1 trimesh): 32 bytes per vertex
    +0  position XYZ  (3 × float32 = 12 bytes)
    +12 normal  XYZ   (3 × float32 = 12 bytes)
    +24 UV      ST    (2 × float32 =  8 bytes)
